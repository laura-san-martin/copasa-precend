
<div class="copasa__video">
    <iframe src="<?php echo $video ?>" frameborder="0"
        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
    </iframe>
</div>

